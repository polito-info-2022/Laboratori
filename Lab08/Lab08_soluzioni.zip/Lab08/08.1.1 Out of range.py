# Esercizio 08.1.1
# Out of range

dati = [1, 2, 3]
lunghezza = len(dati)
print(dati[lunghezza])