# Esercizio 01.2.13
# Fibonacci(4)

fib1 = 1
fib2 = 1
fib3 = fib1 + fib2
fib4 = fib2 + fib3

print(fib4)
