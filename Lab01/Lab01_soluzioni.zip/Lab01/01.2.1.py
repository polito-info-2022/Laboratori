# Esercizio 01.2.1
# Scrivere una frase di inaugurazione delle esercitazioni del corso di informatica.

print("Benvenuti al corso di Informatica!")
