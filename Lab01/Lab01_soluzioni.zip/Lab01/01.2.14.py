# Esercizio 01.2.14
# Fibonacci(1...4)

fib1 = 1
print(fib1)

fib2 = 1
print(fib2)

fib3 = fib1 + fib2
print(fib3)

fib4 = fib2 + fib3
print(fib4)
