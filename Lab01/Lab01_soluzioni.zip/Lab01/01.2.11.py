# Esercizio 01.2.11
# 100 simboli '-'

print('-' * 100)
