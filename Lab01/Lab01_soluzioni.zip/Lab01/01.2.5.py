# Esercizio 01.2.5
# Scrivete il vostro nome, in colonna

print('J')
print('o')
print('h')
print('n')
