# Esercizio 01.2.8
# Display an animal speaking a greeting.
#
print(" /\\_/\\    ________________")
print("( o o )  /                \\")
print("==_Y_== < Computer Science >")
print("  '-'    \\________________/")

