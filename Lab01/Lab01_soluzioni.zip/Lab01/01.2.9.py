# Esercizio 01.2.9
# Un codice alfanumerico lungo 16 caratteri che alterni le stringhe “abcd” e “1234”

# l'argomento end='' sopprime il carattere di a-capo, permettendo di stampare gli elementi successivi sulla stessa riga
print('abcd', end='')
print('1234', end='')
print('abcd', end='')
print('1234', end='')
print()
