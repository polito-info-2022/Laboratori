# Esercizio 01.2.2
# Stampa la somma dei primi 10 numeri interi positivi

somma = 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10

print('La somma dei primi 10 interi vale', somma)
