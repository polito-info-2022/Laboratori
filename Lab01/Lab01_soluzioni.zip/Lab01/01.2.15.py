# Esercizio 01.2.15
# Frase di chiusura

esercizi_totali = 15
esercizi_risolti = 14
percentuale = esercizi_risolti / esercizi_totali * 100
saluto = 'Arrivederci'

print('*' * (len(saluto) + 6))
print('**', saluto, '**')
print('*' * (len(saluto) + 6))

print('Esercizi risolti', percentuale, '%')
