# Esercizio 01.2.10
# Scacchiera 5x5

riga_dispari = '01010'
riga_pari = '10101'

print(riga_dispari) #1
print(riga_pari) #2
print(riga_dispari) #3
print(riga_pari) #4
print(riga_dispari) #5
