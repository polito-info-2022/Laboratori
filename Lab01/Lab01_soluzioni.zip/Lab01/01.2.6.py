# Esercizio 01.2.6
# Saldo di un conto corrente bancario

balance = 1000

#  The balance after year one.
balance = balance + balance * 0.05
print('After year 1, the balance is', balance)

#  The balance after year two.
balance = balance + balance * 0.05
print('After year 2, the balance is', balance)

#  The balance after year three.
balance = balance + balance * 0.05
print('After year 3, the balance is', balance)
