# Esercizio 01.2.7
# Name in a box.
#
print("+-----+")
print("| Ben |")
print("+-----+")

