# Esercizio 01.2.4
# Scrivere un nome con lettere grandi
#
print("****   *****  *   *")
print("*  **  *      **  *")
print("****   ****   * * *")
print("*  **  *      *  **")
print("****   *****  *   *")

