# Esercizio 01.2.12
# 100 simboli '0'

print('0' * 100)

# Attenzione: usare '0' come stringa e non '0' come numero
# Sarebbe errato scrivere:
# print(0 * 100)
# Perché? cosa stamperebbe?