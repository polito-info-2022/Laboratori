# Esercizio 02.1.1
# Calcoli con due numeri

a = 312
b = -27

somma = a + b
print('Somma', somma)

differenza = a - b
print('Differenza', differenza)

prodotto = a * b
print('Prodotto', prodotto)

media = somma / 2
print('Media', media)

distanza = abs(differenza)
print('Distanza', distanza)

massimo = max(a, b)
print('Massimo', massimo)

minimo = min(a, b)
print('Minimo', minimo)
