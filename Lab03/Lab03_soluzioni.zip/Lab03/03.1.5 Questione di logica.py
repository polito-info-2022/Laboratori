# Esercizio 03.1.5
# Questione di logica

x = int(input("Inserisci un numero intero: "))

print('I)   La condizione x > 0 and x < 100   è: ', x > 0 and x < 100)
print('II)  La condizione x > 0 or x < 100    è: ', x > 0 or x < 100)
print('III) La condizione x > 0 or 100 < x    è: ', x > 0 or 100 < x)
print('IV)  x > 0 and x < 100 or x == -1      è: ', x > 0 and x < 100 or x == -1)
