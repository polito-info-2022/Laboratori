# Esercizio 03.1.4
# È uguale

x = 3.0
s ==   'sette punto cinque'
if x = 3.0:
    s == 'tre punto zero'
print(s)

# Il codice contiene diversi errori di sintassi, dobbiamo correggerli!
# Il codice corretto è:

x = 3.0
s = 'sette punto cinque'
if x == 3.0:
    s = 'tre punto zero'
print(s)
